"""Assemble an evidence ledger from saved studies; never invent missing results.

This is a manuscript starting point and scope audit, not an automatic novelty
or publication certificate. It reads numeric summaries and records their paths.
"""
import argparse
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs",nargs="+",required=True,type=Path)
    args=parser.parse_args()
    text=["# Driven finite-lattice Schwinger study: evidence ledger\n",
          "This document is generated from saved results. It is a manuscript starting point; "
          "a completed numerical scan alone does not establish novelty or a tunneling mechanism.\n",
          "## Question and method\n",
          "Which neutral excitations does a compact external-field pulse reach, and how does a strong "
          "Sauter background change the response to a weak component? The model uses open boundaries, "
          "the repository stagger convention, exact sector ground states, chronological sparse propagation "
          "and finite-waveform response predictions. Vacuum survival loss Y is distinct from a mean pair count.\n",
          "## Saved evidence\n",
          "| Run | Saved rows | Kind | Evidence |\n| --- | ---: | --- | --- |"]
    allrows=[]
    for run in args.runs:
        run=run.resolve()
        meta=json.loads((run/"metadata.json").read_text())
        rows=json.loads((run/"summary.json").read_text())
        kind=meta["signature"]["kind"]
        description=""
        if kind=="checks": description=f"Validation passed: {all(r['passed'] for r in rows)}"
        elif kind=="spectrum": description=f"neutral dimensions: {sorted(set(r['sector_dimension'] for r in rows))}"
        elif kind=="circuit": description="Exact and VQE preparation; equal-duration no-drive controls; local rotations"
        else:
            resolved=sum(r.get("effect_resolved",False) for r in rows)
            description=f"Y range {min(r['Y'] for r in rows):.5g} to {max(r['Y'] for r in rows):.5g}; {resolved} resolved nonadditive points"
            allrows.extend(rows)
        relative=run.relative_to(ROOT)
        text.append(f"| [{run.name}](../{relative}/summary.json) | {len(rows)} | {kind} | {description} |")
    if allrows:
        norm=max(r["trajectories"]["both"]["max_norm_error"] for r in allrows)
        work=max(r["trajectories"]["both"]["max_work_residual"] for r in allrows)
        text += ["\n## Numerical status\n",f"Largest recorded combined-run norm drift: {norm:.6g}. "
                 f"Largest recorded combined-run work residual: {work:.6g}. "
                 "Point metadata contain the actual settings, grid, code archive and refinement references.\n"]
        responsive=[r for r in allrows if "Y_pump_prediction" in r]
        if responsive:
            absolute=[abs(r["Y"]-r["Y_pump_prediction"]) for r in responsive]
            text.append(f"Strong-background second-order predictions were evaluated at {len(responsive)} points; "
                        f"the maximum absolute Y difference is {max(absolute):.6g}. "
                        "Inspect amplitude dependence before treating this as an adequate explanation.\n")
    text += ["\n## Interpretation and paper boundary\n",
        "The response about the strong background retains the second-order auxiliary-state interference term. "
        "Compare it with the Fourier prediction about the initial vacuum, the sign/delay/peak/budget controls "
        "and final eigenstate populations. K_Y is the lattice additive-yield ratio. A resolved D_Y or a ratio "
        "above unity alone does not identify a tunneling mechanism. Spatial and size tests determine whether "
        "an effect is dominated by boundaries or finite volume. Fixed-a size tests are not a continuum limit.\n",
        "## Figure assembly\n",
        "Use the saved-data plotter for spectra (1), weak response (2), Case A (3), response/spatial diagnostics (4), "
        "background probes (5), size/coupling comparisons (6), and circuit errors/resources (7). "
        "Automatic selections are saved beside the figures. No manual point removal is implied.\n",
        "## Closest baselines\n",
        "[Ghim and Honda, arXiv:2404.14788v1](https://arxiv.org/html/2404.14788v1) "
        "study digital Schwinger spectroscopy with time-oscillating quenches and survival readout. "
        "Their operators and parameter conventions must be distinguished from this background-flux drive.\n",
        "[Aleksandrov et al., arXiv:2210.15626v3](https://arxiv.org/html/2210.15626v3) "
        "compare rapid field switch-off with dynamical assistance for prescribed external fields. "
        "Their continuum enhancement comparison does not define the finite-lattice K_Y used here.\n",
        "## Remaining scientific decisions\n",
        "A publishable claim requires a discriminating explanation supported by the saved controls and "
        "convergence checks, adequate size/coupling tests, and a fresh nearest-literature assessment. "
        "A complete continuum extrapolation, hardware demonstration and quantum advantage are not established "
        "by these finite statevector calculations. Report negative or unresolved effects explicitly.\n"]
    destination=ROOT/"docs/driven_results.md"
    destination.write_text("\n".join(text))
    print(destination)


if __name__=="__main__":main()
