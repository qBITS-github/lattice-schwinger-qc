"""Cached vacuum-relative observables, shared by reference and circuit runs."""
import numpy as np
from scipy.integrate import trapezoid


def make_observer(ops, vacuum, pulse, background=0.):
    """Return a function (t, psi) -> physical observables without normalization.

    Q and Q**2 use the diagonal charge of every basis state. In a neutral
    sector P_neutral equals the norm; in a full statevector it detects leakage.
    Y is the norm of the vacuum-orthogonal component, avoiding cancellation.
    W uses (H(background)-E0)|psi>, which is also stable for tiny signals.
    """
    q, occ, L0 = ops.q, ops.occupation, ops.L0
    probability0 = abs(vacuum)**2
    charge0, occupation0 = probability0@q, probability0@occ
    charge_diag = q.sum(axis=1)
    Href = ops.hamiltonian(background)
    E0 = float(np.vdot(vacuum, Href@vacuum).real)

    def observe(t, psi):
        probability = abs(psi)**2
        norm = float(probability.sum())
        eps = float(pulse.epsilon(t))
        orthogonal = psi-vacuum*np.vdot(vacuum, psi)
        charges = probability@q
        occupation = probability@occ
        L = L0+eps
        energy0 = np.vdot(psi, ops.H0@psi).real
        W = np.vdot(psi, Href@psi-E0*psi).real
        return {
            "Y": float(np.vdot(orthogonal, orthogonal).real), "W": float(W),
            "energy": float(energy0+eps*(probability@ops.V)+ops.c*eps**2*norm),
            "electric_energy": float(ops.g**2*ops.a/2*(probability@np.sum(L*L, axis=1))),
            "N_exc": float(occupation.sum()),
            "N_excess": float((occupation-occupation0).sum()),
            "charge": charges-charge0, "occupation": occupation-occupation0,
            "electric_profile": probability@L,
            "norm": norm, "Q": float(probability@charge_diag),
            "Q2": float(probability@(charge_diag**2)),
            "P_neutral": float(probability[np.abs(charge_diag) < .5].sum()),
        }
    return observe


def summarize(trajectory, pulse_end, N, post_duration=10.):
    """Endpoint values, post-pulse means, and explicit conservation diagnostics."""
    times, values = trajectory.times, trajectory.observations
    endpoint = int(np.argmin(abs(times-pulse_end)))
    if abs(times[endpoint]-pulse_end) > 1e-9:
        raise ValueError("Sampling must include pulse_end exactly")
    summary = {name: np.asarray(value[endpoint]).tolist() for name, value in values.items()}
    post = (times >= pulse_end) & (times <= pulse_end+post_duration+1e-10)
    for name in ("N_excess", "charge", "occupation", "electric_profile", "electric_energy"):
        if post_duration > 0 and post.sum() >= 2:
            summary[name+"_average"] = (trapezoid(values[name][post], times[post], axis=0)
                                        /(times[post][-1]-times[post][0])).tolist()
    summary["W_per_site"] = summary["W"]/N
    summary["max_norm_error"] = float(np.max(abs(values["norm"]-1)))
    summary["max_charge_squared"] = float(np.max(abs(values["Q2"])))
    summary["max_work_residual"] = float(np.max(abs(values["energy"]-values["energy"][0]-trajectory.work)))
    summary["post_Y_drift"] = float(np.ptp(values["Y"][post]))
    summary["post_W_drift"] = float(np.ptp(values["W"][post]))
    return summary
