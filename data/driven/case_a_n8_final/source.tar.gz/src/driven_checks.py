"""Maintained numerical checks, including the earlier charge-sector anchors."""
import numpy as np
from scipy.optimize import brentq

from driven_model import build_sector_operators, sector_ground_state, transition_spectrum
from driven_observables import make_observer, summarize
from pulses import Constant, Sauter, Sine, Sum, pulse_components
from schwinger_model import build_hamiltonian, evolve
from time_evolution import propagate, sampling_grid
from response import linear_response, squared_drive


def run_checks(store, cfg):
    specification = {"kind": "validation", "config": cfg}
    def compute():
        ops = build_sector_operators(**cfg["model"])
        E0, vacuum = sector_ground_state(ops)
        spectrum = transition_spectrum(ops)
        strong, weak = pulse_components(cfg["pulse"])
        pulse = Sum((strong, weak))
        start, end = pulse.interval
        times = sampling_grid(start, end+10/ops.g, .1/ops.g, [*pulse.boundaries, end])
        observer = make_observer(ops, vacuum, pulse)
        adaptive = propagate(ops, pulse, vacuum, times, energy_shift=E0,
                              observer=observer, max_step=.025/ops.g)
        check = summarize(adaptive, end, ops.N, 10/ops.g)
        errors, midpoint_Y, midpoint_W = [], [], []
        for h in (.02/ops.g, .01/ops.g, .005/ops.g):
            result = propagate(ops, pulse, vacuum, times, method="midpoint", max_step=h,
                               energy_shift=E0, observer=observer, store_states=False)
            overlap = np.vdot(adaptive.final_state, result.final_state)
            aligned = result.final_state*np.exp(-1j*np.angle(overlap))
            errors.append(float(np.linalg.norm(aligned-adaptive.final_state)))
            summary = summarize(result, end, ops.N, 10/ops.g)
            midpoint_Y.append(summary["Y"]); midpoint_W.append(summary["W"])
        constant_times = np.linspace(0, 2/ops.g, 21)
        constant_errors = []
        for eps in (0., .3):
            constant = Constant(eps, *constant_times[[0,-1]])
            actual = propagate(ops, constant, vacuum, constant_times, max_step=.025/ops.g)
            reference = evolve(vacuum, ops.hamiltonian(eps), constant_times)
            reference *= np.exp(1j*ops.c*eps**2*constant_times[:,None])
            constant_errors.append(float(np.max(abs(actual.states-reference))))
        matrix_errors = []
        for eps in (-.3, 0., .7):
            full = build_hamiltonian(ops.N,ops.a,ops.m,ops.g,eps)[ops.basis][:,ops.basis].toarray()
            matrix_errors.append(float(np.linalg.norm(full-ops.hamiltonian(eps).toarray())/max(1,np.linalg.norm(full))))
        bright = spectrum["weights"] > 1e-8
        anchors = {"E0": E0, "bright_gap": float(spectrum["gaps"][bright][0]),
                   "bright_weight": float(spectrum["weights"][bright][0])}
        anchor_pass = True
        if ops.N == 8 and ops.a == ops.m == ops.g == 1:
            charged = build_sector_operators(8, Q=-1)
            crossing = brentq(lambda e: sector_ground_state(ops,e)[0]-sector_ground_state(charged,e)[0], .6,.8)
            anchors["charge_crossing"] = crossing
            anchors["neutral_gap_at_crossing"] = float(transition_spectrum(ops,crossing)["gaps"][0])
            expected = [-4.6380577409,2.6579940584,.2165681749,.6923761274,1.3512648343]
            anchor_pass = max(abs(a-b) for a,b in zip(anchors.values(),expected)) < 1e-6
        prediction = linear_response(spectrum, weak)
        status = {"matrix_identity": max(matrix_errors)<1e-12, "spectral_anchors": anchor_pass,
                  "constant_reference": max(constant_errors)<1e-8,
                  "norm": check["max_norm_error"]<1e-9, "charge": check["max_charge_squared"]<1e-12,
                  "work": check["max_work_residual"]<1e-8,
                  "stationary_Y": check["post_Y_drift"]<1e-8,
                  "stationary_W": check["post_W_drift"]<1e-8,
                  "midpoint_Y": abs(midpoint_Y[-1]-check["Y"])<max(1e-8,.01*check["Y"]),
                  "midpoint_W": abs(midpoint_W[-1]-check["W"])<max(1e-8,.01*abs(check["W"]))}
        arrays = {"times": times, "integration_times": adaptive.integration_times,
                  "source_work": adaptive.work, **adaptive.observations,
                  "midpoint_h": np.array([.02,.01,.005])/ops.g,
                  "midpoint_state_error": np.array(errors), "midpoint_Y": np.array(midpoint_Y),
                  "midpoint_W": np.array(midpoint_W), "gaps": spectrum["gaps"], "weights": spectrum["weights"]}
        info = {"passed": bool(all(status.values())), "checks": status, "anchors": anchors,
                "matrix_residuals": matrix_errors, "constant_errors": constant_errors,
                "midpoint_state_errors": errors, "Y_LR": prediction["Y"], **check}
        return arrays, info
    _, info, identifier = store.point(specification, compute)
    return {"point": identifier, **info}
