"""Second-order midpoint circuits and direct local-gate state updates.

No dense global unitary and no matrix-to-Pauli decomposition is used. The
sector simulator applies the same exchange gates as the full statevector.
The diagonal phase is evaluated directly; circuit RZ/RZZ coefficients below
are derived by expanding the cumulative electric energy.
"""
import numpy as np

from driven_model import build_sector_operators, sector_ground_state
from driven_observables import make_observer, summarize
from pulses import Constant, Sum, pulse_components
from time_evolution import propagate, sampling_grid


def local_step(ops, psi, eps, h):
    """D/2, even hopping/2, odd hopping, even hopping/2, D/2.

    Each hopping bond acts on |01>,|10> with cos(d/2a) I - i sin(d/2a) X.
    Index-pair copies avoid in-place aliasing. All updates preserve charge.
    The c*eps**2 identity is omitted, consistently with the reference solver.
    """
    state = psi.copy()
    diagonal = ops.H0.diagonal()+eps*ops.V
    phase = np.exp(-.5j*h*diagonal)
    state *= phase
    for parity, duration in ((0,h/2),(1,h),(0,h/2)):
        angle = duration/(2*ops.a)
        c, s = np.cos(angle), -1j*np.sin(angle)
        for left,right in ops.bonds[parity::2]:
            u,v = state[left].copy(), state[right].copy()
            state[left] = c*u+s*v; state[right] = s*u+c*v
    return state*phase


def diagonal_coefficients(N, a=1., m=1., g=1., eps=0.):
    """Single-Z, pair-ZZ and scalar coefficients of the physical diagonal H.

    Keys use zero-based physical sites (left to right); circuit construction
    maps these to Qiskit qubit N-1-site. Scalars affect only global phase.
    """
    stagger = (-1.)**np.arange(N)
    partial = np.cumsum(stagger)[:-1]
    z = m/2*stagger
    zz = {}
    scalar = 0.
    for n in range(1,N):
        A = eps+partial[n-1]/2
        z[:n] += g*g*a/2*A
        scalar += g*g*a/2*(A*A+n/4)
        for i in range(n):
            for j in range(i+1,n): zz[i,j] = zz.get((i,j),0.)+g*g*a/4
    return z,zz,scalar


def step_circuit(N, a, m, g, eps, h):
    """Actual RZ/RZZ/RXX/RYY circuit, matching local_step up to global phase."""
    from qiskit import QuantumCircuit
    circuit = QuantumCircuit(N)
    z,zz,_ = diagonal_coefficients(N,a,m,g,eps)
    def diagonal(duration):
        for site,coefficient in enumerate(z): circuit.rz(2*duration*coefficient,N-1-site)
        for (i,j),coefficient in zz.items(): circuit.rzz(2*duration*coefficient,N-1-i,N-1-j)
    diagonal(h/2)
    for parity,duration in ((0,h/2),(1,h),(0,h/2)):
        for i in range(parity,N-1,2):
            q,r = N-1-i,N-2-i
            circuit.rxx(duration/(2*a),q,r)
            circuit.ryy(duration/(2*a),q,r)
    diagonal(h/2)
    return circuit


def run_circuit_point(store, cfg):
    """Compare exact and frozen VQE preparation, including equal-time no-drive.

    The frozen VQE state is read as an input artifact, never projected into
    Q=0 or reoptimized. Full-state diagnostics expose its charge leakage.
    Return to preparation is reported separately from exact-vacuum excitation.
    """
    from driven_io import ROOT
    from driven_study import ground
    model = {**cfg["model"],"Q":None}
    ops = build_sector_operators(**model)
    if ops.N > 16: raise ValueError("Statevector benchmark is limited to N<=16")
    E0,vacuum,_ = ground(store,ops,model,0.)
    strong,weak = pulse_components(cfg["pulse"])
    pulse = Sum((strong,weak))
    a,b = pulse.interval
    times = sampling_grid(a,b+cfg["readout"]["post_pulse_duration"],
                           cfg["readout"]["sampling_interval"],[*pulse.boundaries,b])
    preparations = {"exact":vacuum}
    if cfg.get("analysis",{}).get("vqe_preparation",True):
        if ops.N != 8 or not all(cfg["model"][p] == 1 for p in ("a","m","g")):
            raise ValueError("Frozen VQE input is only N=8, a=m=g=1")
        with np.load(ROOT/"data/VQE/table1_n8.npz",allow_pickle=False) as data:
            preparations["VQE"] = data["psi_vqe"]
    row = {"preparations":{}}
    h = cfg["integrator"]["max_step"]
    for name,initial in preparations.items():
        record = {}
        for label,drive in (("pulse",pulse),("no_drive",Constant(0.,a,b))):
            specification={"kind":"circuit","model":model,"pulse":drive.metadata(),"times":times,
                           "h":h,"preparation":name,"initial_state":initial,
                           "readout":cfg["readout"]}
            # Complex amplitudes cannot be JSON keys; fingerprint exact bytes.
            from hashlib import sha256
            specification["initial_state"] = sha256(initial.tobytes()).hexdigest()
            def compute(drive=drive,initial=initial):
                observer = make_observer(ops,vacuum,drive)
                reference = propagate(ops,drive,initial,times,method="DOP853",max_step=min(.025,h),
                                      observer=observer,store_states=False,energy_shift=E0)
                # local_step has its own phase origin; fidelity removes it.
                circuit = propagate(ops,drive,initial,times,method="trotter",max_step=h,
                    stepper=lambda state,eps,d: local_step(ops,state,eps,d),observer=observer,store_states=False)
                metrics = summarize(circuit,b,ops.N,cfg["readout"]["post_pulse_duration"])
                ref = summarize(reference,b,ops.N,cfg["readout"]["post_pulse_duration"])
                metrics.update({"Y_reference":ref["Y"],"W_reference":ref["W"],
                    "Y_error":abs(metrics["Y"]-ref["Y"]),"W_error":abs(metrics["W"]-ref["W"]),
                    "prepared_vacuum_fidelity":float(abs(np.vdot(vacuum,initial))**2),
                    "return_to_prepared_final":float(abs(np.vdot(initial,circuit.final_state))**2),
                    "return_to_prepared_reference_final":float(abs(np.vdot(initial,reference.final_state))**2),
                    "final_state_fidelity":float(abs(np.vdot(reference.final_state,circuit.final_state))**2)})
                sample_circuit=step_circuit(ops.N,ops.a,ops.m,ops.g,float(drive.epsilon((a+b)/2)),h/2)
                two_qubit=sum(instruction.operation.num_qubits==2 for instruction in sample_circuit.data)
                # Propagate uses two frozen-H half-steps for its work quadrature.
                steps=len(circuit.integration_times)-1
                metrics["two_qubit_gates"]=2*two_qubit*steps
                metrics["cx_equivalent_upper_bound"]=2*metrics["two_qubit_gates"]
                Y=max(metrics["Y"],1e-300)
                metrics["ideal_shots_for_10_percent_relative_Y"]=float((1-Y)/(.1**2*Y))
                arrays={"times":times,"integration_times":circuit.integration_times,
                        "source_work":circuit.work,**circuit.observations,
                        "Y_reference":reference.observations["Y"],"W_reference":reference.observations["W"]}
                return arrays,metrics
            _,info,identifier=store.point(specification,compute)
            record[label]={"point":identifier,**info}
        row["preparations"][name]=record
    row["h"]=h
    row["Y"]=row["preparations"]["exact"]["pulse"]["Y"]
    return row
