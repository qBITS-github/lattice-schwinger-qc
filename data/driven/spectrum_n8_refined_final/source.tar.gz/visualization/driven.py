"""Plot saved driven-study data only; never start a simulation while plotting.

The selection of time traces is automatic and written to plot_selection.json.
Every output is under figures/driven/<run_id>, never a reproduction directory.
"""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import sys

os.environ.setdefault("MPLCONFIGDIR", "/tmp/schwinger-matplotlib")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
sys.path.insert(0,str(ROOT/"visualization/deps"))
from style import apply_style
from driven_io import run_paths
from pulses import Sum,pulse_components
from response import fourier


def load_point(run,identifier):
    numeric=run/"points"/(identifier+".npz")
    metadata=json.loads(numeric.with_suffix(".json").read_text())
    if sha256(numeric.read_bytes()).hexdigest()!=metadata["npz_sha256"]:
        raise ValueError(f"Corrupt plot input {numeric}")
    with np.load(numeric,allow_pickle=False) as data:
        return {key:data[key] for key in data.files}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir",type=Path,required=True)
    args=parser.parse_args()
    run=args.run_dir.resolve()
    expected,output=run_paths(run.name)
    if run!=expected.resolve(): raise ValueError("Use a data/Driven/<run_id> directory")
    rows=json.loads((run/"summary.json").read_text())
    meta=json.loads((run/"metadata.json").read_text())
    kind=meta["signature"]["kind"]
    apply_style()
    def save(fig,name):
        fig.suptitle(f"DRIVEN STUDY — {run.name}",fontsize=11)
        fig.tight_layout()
        fig.savefig(output/(name+".png"),dpi=160,bbox_inches="tight")
        fig.savefig(output/(name+".pdf"),bbox_inches="tight")
        plt.close(fig)
    if kind=="spectrum":
        fig,axes=plt.subplots(1,3,figsize=(15,4))
        for row in rows:
            data=load_point(run,row["point"])
            gaps,weights=data["gaps"],data["weights"]
            axes[0].scatter(np.full(len(gaps),row["epsilon"]),gaps,s=3+100*weights/max(row["variance"],1e-30),
                            c=weights,cmap="viridis",vmin=0,vmax=.3,alpha=.7)
            if "unrestricted_energies" in data:
                axes[1].scatter(np.full(len(data["unrestricted_energies"]),row["epsilon"]),
                    data["unrestricted_energies"]-row["E0"],c=data["unrestricted_charges"],
                    cmap="coolwarm",vmin=-4,vmax=4,s=2)
        zero=min(rows,key=lambda r:abs(r["epsilon"]))
        data=load_point(run,zero["point"])
        axes[2].vlines(data["gaps"],0,data["weights"])
        axes[0].set(xlabel="background epsilon",ylabel="neutral gap",ylim=(0,8),title="Drive weights set marker size/color")
        axes[1].set(xlabel="background epsilon",ylabel="E - neutral E0",ylim=(-2,8),title="All sectors; color is Q")
        axes[2].set(xlabel="neutral gap",ylabel="transition weight",xlim=(0,8),title=f"epsilon={zero['epsilon']}")
        save(fig,"01_spectra")
    elif kind=="checks":
        data=load_point(run,rows[0]["point"])
        fig,axes=plt.subplots(1,3,figsize=(14,4))
        axes[0].plot(data["times"],data["energy"]-data["energy"][0],label="physical energy change")
        axes[0].plot(data["times"],data["source_work"],"--",label="integrated source work")
        axes[0].legend(); axes[0].set(xlabel="time",ylabel="energy / work")
        axes[1].semilogy(data["times"],np.maximum(abs(data["norm"]-1),1e-17),label="norm drift")
        axes[1].semilogy(data["times"],np.maximum(abs(data["Q2"]),1e-17),label="<Q^2>")
        axes[1].legend();axes[1].set(xlabel="time",ylabel="numerical diagnostic")
        axes[2].loglog(data["midpoint_h"],data["midpoint_state_error"],"o-")
        axes[2].set(xlabel="midpoint step",ylabel="state error vs adaptive")
        save(fig,"validation")
    elif kind=="circuit":
        fig,axes=plt.subplots(1,3,figsize=(15,4))
        for name in rows[0]["preparations"]:
            records=[r["preparations"][name]["pulse"] for r in rows]
            h=[r["h"] for r in rows]
            axes[0].loglog(h,[r["Y_error"] for r in records],"o-",label=name)
            axes[1].loglog([r["two_qubit_gates"] for r in records],[r["Y_error"] for r in records],"o-",label=name)
            axes[2].plot(h,[r["Y"] for r in records],"o-",label=name+" exact-vacuum Y")
            axes[2].plot(h,[1-r["return_to_prepared_final"] for r in records],"x--",label=name+" prepared-state loss")
        axes[0].set(xlabel="field sampling step",ylabel="absolute Y error")
        axes[1].set(xlabel="two-qubit rotations",ylabel="absolute Y error")
        axes[2].set(xlabel="field sampling step",ylabel="survival loss")
        for ax in axes: ax.legend(fontsize=8)
        save(fig,"07_circuit")
    else:
        caseA=any("tau" in r["pulse"] for r in rows)
        xkey="tau" if caseA else "omega"
        def groupkey(r):
            p=r["pulse"]
            return (r["model"]["N"],r["model"]["m"],p.get("epsilon_s",p.get("epsilon_b",0)),p["epsilon_w"],p.get("T_w"),p.get("ramp_duration"))
        groups={}
        for row in rows: groups.setdefault(groupkey(row),[]).append(row)
        fig,axes=plt.subplots(2,2,figsize=(12,8))
        for label,group in groups.items():
            group=sorted(group,key=lambda r:r["pulse"][xkey]); x=[r["pulse"][xkey] for r in group]
            title=f"N={label[0]}, m={label[1]}, pump={label[2]}, weak={label[3]}, T={label[4]}, ramp={label[5]}"
            amplitude=label[3]
            if caseA:
                for variant,style in (("strong",":"),("weak","--"),("both","-")):
                    axes[0,0].plot(x,[r["trajectories"][variant]["Y"] for r in group],style,label=title+" "+variant)
                valid=[r for r in group if r.get("K_Y") is not None]
                if valid: axes[0,1].errorbar([r["pulse"][xkey] for r in valid],[r["K_Y"] for r in valid],
                    yerr=[r["K_Y_uncertainty"] for r in valid],fmt="o-",ms=3,label=title)
                axes[1,0].errorbar(x,[r["D_Y"] for r in group],
                    yerr=[r.get("D_Y_uncertainty",0.) for r in group],fmt="o-",ms=3,label=title)
                if "Y_pump_prediction" in group[0]:
                    axes[0,0].plot(x,[r["Y_pump_prediction"] for r in group],"x",label="pump expansion")
            else:
                axes[0,0].plot(x,[r["Y"]/amplitude**2 for r in group],"o-",ms=3,label=title)
                axes[0,0].plot(x,[r["trajectories"]["both"]["Y_LR"]/amplitude**2 for r in group],"--",alpha=.7)
                axes[0,1].plot(x,[r["W"]/amplitude**2 for r in group],"o-",ms=3,label=title)
                axes[0,1].plot(x,[r["trajectories"]["both"]["W_LR"]/amplitude**2 for r in group],"--",alpha=.7)
                axes[1,0].plot(x,[r.get("D_Y",0) for r in group],"o-",ms=3,label=title)
            axes[1,1].plot(x,[r["W"]/r["model"]["N"] for r in group],"o-",ms=3,label=title)
        labels=["absolute Y" if caseA else "Y / weak amplitude²", "lattice additive-yield ratio K_Y" if caseA else "W / weak amplitude²", "D_Y", "W / N"]
        for ax,label in zip(axes.ravel(),labels):
            ax.set(xlabel=xkey,ylabel=label);ax.legend(fontsize=6)
            if caseA: ax.set_xscale("log")
        axes[1,0].axhline(0,color="k",lw=.5)
        save(fig,"03_case_a" if caseA else "02_case_b")
        if (not caseA and rows[0]["pulse"]["kind"]=="windowed_sine"
                and len(set((r["model"]["N"],r["model"]["m"]) for r in rows))==1):
            fig,axes=plt.subplots(1,3,figsize=(15,4))
            metrics=[]
            for duration in sorted(set(r["pulse"]["T_w"] for r in rows)):
                subset=[r for r in rows if r["pulse"]["T_w"]==duration]
                peak=max(subset,key=lambda r:r["Y"])["pulse"]["omega"]
                for frequency in (1.083,peak):
                    ladder=sorted([r for r in subset if abs(r["pulse"]["omega"]-frequency)<1e-9],
                                  key=lambda r:r["pulse"]["epsilon_w"])
                    amplitudes=np.array([r["pulse"]["epsilon_w"] for r in ladder])
                    yields=np.array([r["Y"] for r in ladder])
                    if len(ladder)>1:
                        resolved=bool(np.all(yields>1e-8))
                        slope=float(np.polyfit(np.log(amplitudes),np.log(yields),1)[0]) if resolved else None
                        axes[0].loglog(amplitudes,yields,"o-",label=f"T={duration}, omega={frequency}")
                        metrics.append({"duration":duration,"omega":frequency,"slope":slope,"resolved":resolved})
                for amplitude in sorted(set(r["pulse"]["epsilon_w"] for r in subset)):
                    curve=sorted([r for r in subset if r["pulse"]["epsilon_w"]==amplitude],key=lambda r:r["pulse"]["omega"])
                    valid=[r for r in curve if r["Y"]>1e-8 and r["trajectories"]["both"]["Y_LR"]>1e-8]
                    axes[1].plot([r["pulse"]["omega"] for r in valid],
                        [r["Y"]/r["trajectories"]["both"]["Y_LR"]-1 for r in valid],label=f"T={duration}, weak={amplitude}")
                    x=np.array([r["pulse"]["omega"] for r in curve]);y=np.array([r["Y"] for r in curve])
                    peak_index=int(np.argmax(y));half=y[peak_index]/2
                    above=np.flatnonzero(y>=half)
                    if len(above)>1 and above[0]>0 and above[-1]<len(x)-1:
                        lo,hi=above[0],above[-1]
                        left=np.interp(half,y[lo-1:lo+1],x[lo-1:lo+1])
                        right=np.interp(half,y[hi:hi+2][::-1],x[hi:hi+2][::-1])
                        width=float(right-left)
                        axes[2].plot(duration,width,"o",label=f"weak={amplitude}")
                        metrics.append({"duration":duration,"amplitude":amplitude,"FWHM_grid_estimate":width})
            axes[0].set(xlabel="weak amplitude",ylabel="Y")
            axes[1].set(xlabel="omega",ylabel="Y / finite-waveform prediction - 1")
            axes[2].set(xlabel="window duration",ylabel="linewidth (grid estimate)")
            for ax in axes:
                if ax.get_legend_handles_labels()[0]: ax.legend(fontsize=7)
            save(fig,"weak_scaling_and_linewidth")
            (output/"response_metrics.json").write_text(json.dumps(metrics,indent=2)+"\n")
        if len(set((r["model"]["N"],r["model"]["m"]) for r in rows))>1:
            fig,axes=plt.subplots(1,3,figsize=(15,4))
            for label,group in groups.items():
                x=[r["pulse"][xkey] for r in group]
                axes[0].plot(x,[r["W"]/r["model"]["N"] for r in group],"o-",label=str(label))
                central,boundary=[],[]
                for row in group:
                    occupation=np.array(row["trajectories"]["both"]["occupation_average"])
                    N=len(occupation);middle=N//2
                    central.append(float(occupation[middle-2:middle+2].mean()))
                    boundary.append(float(np.r_[occupation[:2],occupation[-2:]].mean()))
                axes[1].plot(x,central,"o-",label=str(label))
                axes[2].plot(x,boundary,"o-",label=str(label))
            for ax,title in zip(axes,("W/N","central four sites: excess occupation/site","outer four sites: excess occupation/site")):
                ax.set(xlabel=xkey,ylabel=title);ax.legend(fontsize=6)
            save(fig,"06_size_coupling_spatial")
        # Automatic trace selection is auditable, including absence of assistance.
        selected={"largest_Y":max(rows,key=lambda r:r["Y"])["index"]}
        if caseA:
            selected.update({"largest_D_Y":max(rows,key=lambda r:r["D_Y"])["index"],
                             "smallest_D_Y":min(rows,key=lambda r:r["D_Y"])["index"]})
        (output/"plot_selection.json").write_text(json.dumps({"rule":"extrema over all saved rows",**selected},indent=2)+"\n")
        chosen=next(r for r in rows if r["index"]==selected["largest_Y"])
        data=load_point(run,chosen["trajectories"]["both"]["point"])
        times=data["times"]
        strong,weak=pulse_components(chosen["pulse"]);pulse=Sum((strong,weak))
        fig,axes=plt.subplots(2,3,figsize=(15,8))
        axes[0,0].plot(times,pulse.epsilon(times)); axes[0,0].set(xlabel="time",ylabel="applied epsilon")
        frequencies=np.linspace(0,8,300)
        axes[0,1].semilogy(frequencies,np.maximum(abs(fourier(pulse,frequencies))**2,1e-24))
        axes[0,1].set(xlabel="angular frequency",ylabel="implemented Fourier power")
        for key in ("Y","W","N_excess"): axes[0,2].plot(times,data[key],label=key)
        axes[0,2].legend();axes[0,2].set(xlabel="time")
        for ax,key in ((axes[1,0],"charge"),(axes[1,1],"occupation"),(axes[1,2],"electric_profile")):
            image=ax.pcolormesh(np.arange(data[key].shape[1])+1,times,data[key],shading="auto",cmap="coolwarm")
            fig.colorbar(image,ax=ax);ax.set(xlabel="site/link",ylabel="time",title=key)
        save(fig,"04_trace_and_spatial")
        fig,axes=plt.subplots(1,2,figsize=(11,4))
        axes[0].plot(times,data["energy"]-data["energy"][0],label="energy change")
        axes[0].plot(times,data["source_work"],"--",label="source work");axes[0].legend()
        axes[1].semilogy(times,np.maximum(abs(data["norm"]-1),1e-17),label="norm error")
        axes[1].semilogy(times,np.maximum(abs(data["Q2"]),1e-17),label="Q²");axes[1].legend()
        save(fig,"numerical_diagnostics")
        if caseA and "pump_coefficients" in chosen:
            fig,axes=plt.subplots(1,3,figsize=(15,4))
            for label,group in groups.items():
                x=[r["pulse"]["tau"] for r in group]
                axes[0].plot(x,[r["Y"] for r in group],"o-",label=str(label))
                axes[0].plot(x,[r["Y_pump_prediction"] for r in group],"x--")
                for quantity in ("Y_even","Y_odd"):
                    if quantity in group[0]: axes[1].plot(x,[r[quantity] for r in group],"o-",label=quantity+str(label))
            populations=np.array([r["trajectories"]["both"].get("populations",[]) for r in rows])
            if populations.size:
                axes[2].imshow(populations[:,1:9].T,aspect="auto",origin="lower")
                axes[2].set(xlabel="saved scan row",ylabel="excited eigenstate index")
            for ax in axes[:2]: ax.set_xscale("log");ax.legend(fontsize=6)
            save(fig,"04_response_and_populations")
        if not caseA and any(r["pulse"].get("epsilon_b",0)!=0 for r in rows):
            ramps=sorted(set(r["pulse"].get("ramp_duration",0) for r in rows))
            fig,axes=plt.subplots(len(ramps),2,figsize=(12,4*len(ramps)),squeeze=False)
            stationary=all(r.get("stationary",False) for r in rows)
            for i,duration in enumerate(ramps):
                subset=[r for r in rows if r["pulse"].get("ramp_duration",0)==duration]
                for ax,quantity in zip(axes[i],("Y","W") if stationary else ("D_Y","D_W")):
                    x=[r["pulse"]["omega"] for r in subset];y=[r["pulse"].get("epsilon_b",0.) for r in subset]
                    image=ax.scatter(x,y,c=[r[quantity] for r in subset],s=90,cmap="viridis")
                    fig.colorbar(image,ax=ax)
                    ax.set(xlabel="omega",ylabel="background",title=quantity+("; stationary diagnostic" if stationary else f"; ramp={duration}"))
            save(fig,"05_background_map")
    print(f"Saved figures in {output}")


if __name__=="__main__": main()
